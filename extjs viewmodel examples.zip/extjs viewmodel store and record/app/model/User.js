Ext.define('App.model.User', {
	extend: 'Ext.data.Model'

	,fields: [ 'id', 'name' ]

})