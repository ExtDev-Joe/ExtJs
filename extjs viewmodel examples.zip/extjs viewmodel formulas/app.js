Ext.application({

	name: 'App'

	,requires: [
		'App.view.Main'
	]

	,mainView: 'App.view.Main'

});